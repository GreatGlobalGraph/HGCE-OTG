//
//  CollectionViewCell.swift
//  HGCE OTG
//
//  Created by Mayank Vadaliya on 26/06/19.
//  Copyright © 2019 Mayank Vadaliya. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var img: UIImageView!
}
