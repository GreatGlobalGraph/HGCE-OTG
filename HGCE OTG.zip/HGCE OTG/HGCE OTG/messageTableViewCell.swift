//
//  messageTableViewCell.swift
//  HGCE OTG
//
//  Created by Mayank Vadaliya on 26/06/19.
//  Copyright © 2019 Mayank Vadaliya. All rights reserved.
//

import UIKit

class messageTableViewCell: UITableViewCell {

    @IBOutlet weak var lbllablr: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
