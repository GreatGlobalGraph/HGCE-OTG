//
//  menuTableViewCell.swift
//  HGCE OTG
//
//  Created by Mayank Vadaliya on 22/06/19.
//  Copyright © 2019 Mayank Vadaliya. All rights reserved.
//

import UIKit

class menuTableViewCell: UITableViewCell {

    @IBOutlet weak var lblManu: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
